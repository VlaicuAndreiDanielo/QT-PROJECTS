#include "edge.h"

Edge::Edge() {}
