#include "ui_topologicalgraphwindow.h"

ui_topologicalgraphwindow::ui_topologicalgraphwindow() {}
